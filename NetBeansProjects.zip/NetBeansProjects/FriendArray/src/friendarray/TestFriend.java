/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package friendarray;

/**
 *
 * @author Michael
 */
public class TestFriend {
    public static void main(String[] args){
        
        //Friend freddy = new Friend("Fred");
        
       /// System.out.println(freddy);
        
        
    }
}
