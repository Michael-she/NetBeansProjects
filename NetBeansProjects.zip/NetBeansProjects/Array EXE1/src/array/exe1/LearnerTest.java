/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package array.exe1;

/**
 *
 * @author Michael
 */
public class LearnerTest {
    public static void main (String[] args){
        Learner sammy = new Learner("Sammy",30,70,98);
        
        System.out.println(sammy);
    }
}
